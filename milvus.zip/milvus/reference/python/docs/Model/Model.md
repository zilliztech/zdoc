# Model

Embedding models for you to embed unstrucctured data into vector embeddings.

<DocCardList />
