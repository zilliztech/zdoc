# grant()

This operation grants a privilege to the current role.

<div class="admonition note">

<p><b>notes</b></p>

<p>To complete this operation, you need to enable authentication on your Milvus instance. For details, refer to <a href="https://milvus.io/docs/authenticate.md">Authenticate User Access</a>.</p>

</div>

## Request Syntax

```python
grant(
    object: str,
    object_name: str,
    privilege: str,
    db_name: str
) 
```

__PARAMETERS:__

- __object__ (_string_)

    __[REQUIRED]__

    The type of the object to grant the privilege.

    The value is case-sensitive, and possible options are __Collection__, __Global__, and __User__. For details, refer to [Users & Roles](https://milvus.io/docs/users_and_roles.md).

- __object_name__ (_string_)

    __[REQUIRED]__

    The name of a target object of the type specified in __object__.

    It can be a collection name, a user name, or a wild card (*).

- __privilege__ (_string_)

    __[REQUIRED]__

    The name of the privilege to grant.

    Applicable privileges vary with the specified __object__. For details, refer to refer to [Users & Roles](https://milvus.io/docs/users_and_roles.md).

    <div class="admonition note">

    <p><b>notes</b></p>

    <ul>
    <li><p>To grant all privileges to a kind of object, like <strong>Collection</strong>, <strong>Global</strong>, <strong>User</strong>, use <code>*</code> for privilege name.</p></li>
    <li><p>When <code>object</code> is set to <code>Global</code>, setting <code>privilege</code> to <code>*</code> is not equivalent to setting it to <code>All</code>. The <code>All</code> privilege includes all permissions, including any collection and user object.</p></li>
    </ul>

    </div>

- __db_name__ (_string_)

    The name of a database the object belongs to. If left unspecified, the default database applies.

__RETURN TYPE:__

_NoneType_

__RETURNS:__

_None_

__EXCEPTIONS:__

- __MilvusException__

    This exception will be raised when any error occurs during this operation.

## Examples

```python
from pymilvus import Role

# Get an existing role
role = Role(role_name)

# Grant a privilege to the current role 
role.grant("Collection", collection_name, "Insert")
```

## Related operations

The following operations are related to `grant()`:

- [add_user()](./Role-add_user)

- [create()](./Role-create)

- [drop()](./Role-drop)

- [get_users()](./Role-get_users)

- [is_exist()](./Role-is_exist)

- [list_grant()](./Role-list_grant)

- [list_grants()](./Role-list_grants)

- [remove_user()](./Role-remove_user)

- [revoke()](./Role-revoke)

