---
slug: /search-query-get
beta: FALSE
notebook: FALSE
type: origin
token: AAJnwIbLViyZzgk6el3c3DERnpf
sidebar_position: 5
---

# Search, Query & Get

This series of guides demonstrate similarity searches and scalar queries in a Milvus collection.

<DocCardList />