---
slug: /milvus-docs
beta: FALSE
notebook: FALSE
type: origin
token: E9oXwLGadieAWfknYfjcbsKEnBg
sidebar_position: 21
---

# Milvus Docs

These are dedicated docs for Milvus, and should not be included in any Zilliz Cloud publications.

<DocCardList />