---
slug: /get-started
beta: FALSE
notebook: FALSE
type: origin
token: BDOHwqlMDiei78kdUefcjSQUnEg
sidebar_position: 1
keywords: 
  - zilliz cloud
  - get started
---

# Get Started

A comprehensive quick start guide and related topics to help you build your apps on Zilliz Cloud.

<DocCardList />